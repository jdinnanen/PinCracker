# jQuery playSound

This plugin defines $.playSound function.
```
 $.playSound('http://example.org/sound')
 $.playSound('http://example.org/sound.wav')
 $.playSound('/attachments/sounds/1234.wav')
 $.playSound('/attachments/sounds/1234.mp3')
 
 //Stop Sound
 $.stopSound();
```
Demo: https://jsfiddle.net/admsev/xscxya0g/

Enjoy it!

That's all folks!
